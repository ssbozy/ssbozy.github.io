---
title: The JWZ test
date: 2025-01-23
---

> Your "use case" should be, there’s a 22 year old college student living in the dorms. How will this software get him laid?

− Jamie Zawinski