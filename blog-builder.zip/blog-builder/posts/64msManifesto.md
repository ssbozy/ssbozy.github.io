---
title: The 64 Milliseconds Manifesto
date: 2020-01-13
---

In an interactive software application, any user action SHOULD result in a noticeable change within 16ms, actionable information within 32ms, and at least one full screen of content within 64ms. - Anders Pitman, The 64 Milliseconds Manifesto
