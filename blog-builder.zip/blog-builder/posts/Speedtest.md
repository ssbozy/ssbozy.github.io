---
title: Speedtest
date: 2017-10-16
---

#Speedtest

A very good location to test download speeds. Has sample files from 5MB to 1GB.

http://www.thinkbroadband.com/download/
