---
title: What to say
date: 2022-11-17
---


When I lost my mom last year, I was very busy with a lot of activities at home. I got a lot of phone calls from friends and family who could not make it in person due to COVID-19. A lot of those phone calls were either about how they feel about losing my mother or other anecdotes of people dying due to COVID. I understand that their intentions were right but they did not know what to speak. I expected something like this: 

“Hey, I heard about the news. I don’t have the right words and please don’t feel obligated to reply. Just know that if I can do something, big or small, now or in the future, I’m just a text away.”

Thank you Anh-Tho Chuong Degroote for saying it out for all of us. Anh is CEO of Lago(https://www.getlago.com/).

