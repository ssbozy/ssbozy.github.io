---
title: Computers are a Sadness, I am the Cure
date: 2025-03-14
---

This is a really good talk. Have a look.

https://vimeo.com/95066828

