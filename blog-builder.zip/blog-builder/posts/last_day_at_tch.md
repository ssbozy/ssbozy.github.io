---
title: Last day at Technicolor
date: 2018-02-02
---
#Last day at Technicolor

After 8 years working for [Technicolor Research and Innovation](http://technicolorbayarea.com), I have decided it's time to move on. Over these many years, I have learnt a lot from some really amazing collegues and ex-collegues. I was mentored by the always wonderful [Jean Bolot](http://bolot.org/). I really want to thank him for believing in me, placing his trust in me and pushing me towards where I wanted to be. Very rarely does anyone meet a mentor like him. There are many such people I met at Technicolor whom I want to thank today.

* Ashwin Kashyap (first boss, best boss)
* Saurabh Mathur
* Peter Papatheodorou (how can I forget you Pete :))
* Brano Kveton
* Nadia Fawaz (Thanks for being the one person I could share everything.)
* Brian Eriksson (Thank you for all the advice)
* Ajith Pudhiyaveetil (we started as Interns in 2010 and became best buddies for life)
* Simon Feltman (only other guy with whom I could nerd all day)
* Akshay Pushparaja (I hired him as an intern but became buddies soon)
* Ken Nguyen (This guy is the best IT guy I have met in ages. Also, best buddy)

I hope I did not forget anyone here. Every one of you changed me one way or other. I have no hard feelings or regrets. I always looked for an opportunity to learn something from everyone of you. I hope I was as helpful too to what you wanted to achieve. Once again, it is emotional to say good bye but I want to explore new challenges now and I hope the best for everyone.

**THANK YOU TECHNICOLOR**