---
title: Rockbottom
date: 2025-01-12
---

I thought to myself if you can hit rock bottom doing the safe things everyone wants you to do, then you might as well hit rock bottom doing what you want to do. - Ashley.C.Ford