---
title: The Conscience of a Hacker
date: 2019-10-24
---

A little excerpt from *The Conscience of a Hacker*:

>Yes, I am a criminal.  My crime is that of curiosity.  My crime is
that of judging people by what they say and think, not what they look like.
My crime is that of outsmarting you, something that you will never forgive me
for.

>I am a hacker, and this is my manifesto.  You may stop this individual,
but you can't stop us all... after all, we're all alike.

[Full read](http://phrack.org/issues/7/3.html) and [Comments on Hacker News](https://news.ycombinator.com/item?id=21346387)