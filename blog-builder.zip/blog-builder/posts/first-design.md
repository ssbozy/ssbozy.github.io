---
title: The first secret of great design
date: 2018-03-06
---

#The first secret of great design

https://www.youtube.com/watch?v=9uOMectkCCs