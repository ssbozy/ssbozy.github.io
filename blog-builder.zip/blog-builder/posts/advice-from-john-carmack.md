---
title: Advice from John Carmack
date: 2018-03-07
---

#Advice from John Carmack

I used a common pattern for me: get first results with hacky code, then write a brand new and clean implementation with the lessons learned, so they both exist and can be cross checked.

-John Carmack