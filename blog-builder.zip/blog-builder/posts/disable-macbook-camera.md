---
title: How to completely disable camera on Mac OSX
date: 2018-03-15
---
#How to completely disable camera on Mac OSX?

I found this wonderful article on how to completely disable the macbook camera through command line. This is not for the faint hearted.
[Here is the link](https://www.macobserver.com/tips/macos-disable-webcam-mac/)

However, if you think you do not possess the kinda skills mentioned here, you can simply buy this [$7 webcam cover](https://www.ebay.com/itm/3-Pcs-Pack-Webcam-Cover-Slider-Camera-Shield-for-Laptop-Pad-Tablet-Phone-Privacy/142638813214?_trkparms=pageci%3A36fb67c3-28b4-11e8-a98c-74dbd1802c4f%7Cparentrq%3A2c4aa2a81620a8840f19512ffffc4689%7Ciid%3A1&_trksid=p2481888.c100675.m4236).

Enjoy your privacy.

