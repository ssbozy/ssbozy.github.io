---
title: My new domain and next steps
date: 2018-04-24
---

# My new domain and next steps

I have been waiting for a long time to share this news with everyone. Earlier this month, I was able to procure my namesake domain. After a significant wait​,​ I am the proud owner of [www.sandilya.com](http://www.sandilya.com). So what does this mean to me and everyone else.

For me​,​ it culminates my efforts to establish my online presence and have a permanent home to eve​r​y​thing​ related to me. For eve​r​yone else, it would be the one location to easily find my updates and acknowledge my work.

Over the coming weeks, I will be migrating all the services from this domain to my new one. I am expecting a very smooth transition with minimal downtime.  I an really looking forward to keep my new home very busy with fresh and new content.

Sandy