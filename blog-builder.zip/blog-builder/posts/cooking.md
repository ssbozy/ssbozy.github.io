---
title: Cooking is meditation
date: 2019-01-16
---

#Cooking is meditation

Try cooking more. It is like meditation. Even if meditation fails, you still have something to eat.   