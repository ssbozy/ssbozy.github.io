---
title: Publii
date: 2017-11-01
---

#Publii

After coming across Publii on Hacker News, I gave it a shot to see if there is promise. It is just fantastic. I switched my blog and website from using Pelican to Publii now. The support from the team is amazing as well. Here are a few benefits of using Publii.

* Supports multiple website handling.
* Muliple hosting options. I am using S3 but Publii supports GitHub and other options.
* Multiple themes. Currently 6 but i think in time it can easily get more.
* Supports Google Analytics and Disqus.
* Blazing fast rendering and S3 sync.

I will document more features as I keep using Publii. Thanks again.