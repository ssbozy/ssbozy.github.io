---
title: Productivity - Note taking and todo tools
date: 2022-01-12
---

I like keeping all my information organized. Sometimes, my friends and family complain about my obsession with folder structures and data organization but, when it comes to important information, I want to be safe than sorry. Here is a list of my go to tools for universal access. 

### Note taking

* [Obsidian](http://obsidian.md/) - All my daily notes go here. I have an iCloud setup which lets me share my docs across multiple devices and iCloud accounts. 
* [Trello](http://trello.com/) - All my todo management lists for home
* [Workflowly](http://workflowy.com/) - I use this when the bullet lists of todos become extremely nested
* [Google Calendar](https://calendar.google.com) - Mostly a reminder/todo tool. 